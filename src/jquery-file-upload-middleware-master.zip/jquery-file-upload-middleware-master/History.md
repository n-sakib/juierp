0.1.3 / 2014-07-05
==================

  * #46 merged in (reduce synchronous disk IO operations)

0.1.2 / 2014-06-08
==================

  * #31 merged in

0.1.1 / 2014-02-04
==================

  * #5 fixed

0.1.0 / 2013-10-07
==================

  * documentation cleanup


0.0.9 / 2013-10-07
==================

  * compatibility with jQuery File Upload Plugin 5.32.6

0.0.8 / 2013-01-01
==================

  * #11 update resize with cropping custom options : imageArgs
    thanks to https://github.com/soomtong

0.0.7 / 2012-12-25
==================

  * 'delete' event merged in, 
    thanks to https://github.com/soomtong

0.0.6 / 2012-12-20
==================

  * #6 hostname option added
  * upload.fileManager() added, which allows moving file

0.0.5 / 2012-12-12
==================

  * #4 fixed - orientation for iphone / ipad photos

0.0.4 / 2012-12-02
==================

  * Syntax changed
  * middleware now provides 'begin','end','abort' events
  * if file was renamed during upload to avoid conflict,
    new field 'originalName' keeps original name
  * dynamic uploadDir and uploadUrl
  * upload.getFiles() added

0.0.3 / 2012-11-25
==================

  * Potential issue fixed

0.0.2 / 2012-11-25
==================

  * Moving files between partitions is now allowed

0.0.1 / 2012-11-08
==================

  * Initial commit
