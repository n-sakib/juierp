## YET ANOTHER JQUERY FILE UPLOAD MIDDLEWARE EXAMPLES

- use bower to install jquery-file-upload script (tested version 8.8.5)

to run

```
project > npm insatll
project > cd examples
project/examples > npm insatll
project/examples > bower insatll
project/examples > node app.js
```

- to image resize : need imagemagick `http://www.imagemagick.org/script/binary-releases.php`